"""LightOps application package."""

__version__ = "0.1.2"
